package com.igpsport.testfitwrapper;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by XZ on 2016-9-27.
 */
public abstract class UartActivityBase extends AppCompatActivity {


    private UartService mUartService;

    public UartService getUartService() {
        return mUartService;
    }

    private LocalBroadcastManager mLocalBroadcastManager;

    private Intent mUartServiceIntent;

    private boolean pauseBrocast = true;
    private boolean isListening = false;
    private boolean isServiceRunning = false;

    private byte[] lastPackage;

    public void setPauseBrocast(boolean pauseBrocast) {
        this.pauseBrocast = pauseBrocast;
    }

    private BroadcastReceiver mUartBrocastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals(UartService.ACTION_GATT_CONNECTED)) {
                onBluetoothConnected();
            } else if (action.equals(UartService.ACTION_GATT_DISCONNECTED)) {
                onBluetoothDisconnected();
            } else if (action.equals(UartService.ACTION_GATT_SERVICES_DISCOVERED)) {
                onBluetoothDiscovered();
            } else if (action.equals(UartService.ACTION_DATA_AVAILABLE)) {
                final byte[] txValue = intent
                        .getByteArrayExtra(UartService.EXTRA_DATA);
                if (txValue != null) {
                    onBluetoothReceiveData(txValue);
                }
            } else if (action.equals(UartService.DEVICE_DOES_NOT_SUPPORT_UART)) {
                onBluetoothNotSupportUART();
            }
        }
    };

    private ServiceConnection mUartServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mUartService = ((UartService.LocalBinder) service).getService();
            onUartServiceConnected();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    protected abstract void onBluetoothConnected();

    protected abstract void onBluetoothDisconnected();

    protected abstract void onBluetoothDiscovered();

    protected abstract void onBluetoothReceiveData(byte[] data);

    protected abstract void onBluetoothNotSupportUART();

    protected abstract void onUartServiceConnected();

    private IntentFilter getUartIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(UartService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(UartService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(UartService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(UartService.ACTION_DATA_AVAILABLE);
        intentFilter.addAction(UartService.DEVICE_DOES_NOT_SUPPORT_UART);
        return intentFilter;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mLocalBroadcastManager = LocalBroadcastManager.getInstance(getApplicationContext());
        //registerReceiver(mUartBrocastReceiver, getUartIntentFilter());
        mLocalBroadcastManager.registerReceiver(this.mUartBrocastReceiver, getUartIntentFilter());
        startService();

    }

    protected void startService() {
        if (!isServiceRunning) {
            mUartServiceIntent = new Intent(this, UartService.class);
            startService(mUartServiceIntent);
            bindService(mUartServiceIntent, this.mUartServiceConnection, BIND_AUTO_CREATE);
            isServiceRunning = true;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //unregisterReceiver(mUartBrocastReceiver);
        mLocalBroadcastManager.unregisterReceiver(mUartBrocastReceiver);
        unbindService(this.mUartServiceConnection);
    }

    protected void stopUartService() {
        try {
            if (isServiceRunning) {
                mUartService.disconnect();
                unbindService(mUartServiceConnection);
                stopService(mUartServiceIntent);
                isServiceRunning = false;
            }
        } catch (Exception ex) {

        }
    }
}
