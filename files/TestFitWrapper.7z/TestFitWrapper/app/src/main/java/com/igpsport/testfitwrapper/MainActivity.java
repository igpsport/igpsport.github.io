package com.igpsport.testfitwrapper;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Environment;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.igpsport.fit.FitConvertReturn;
import com.igpsport.fit.LibFit;
import com.igpsport.fitwrapper.command.CommandBase;
import com.igpsport.fitwrapper.command.CommandType;
import com.igpsport.fitwrapper.command.GetHistoriesListCommand;
import com.igpsport.fitwrapper.command.PackageSender;
import com.igpsport.fitwrapper.parser.HistoryResultParser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

public class MainActivity extends UartActivityBase {


    Button btnConnect, btnGetList;
    EditText edtMac;
    ProgressDialog progressDialog;
    SharedPreferences sharedPreferences;
    CommandType commandType;
    CommandBase commandBase;
    ByteArrayOutputStream byteArrayOutputStream;
    LibFit fit;

    View.OnClickListener btnConnectOnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("mac", edtMac.getText().toString());
            editor.commit();
            progressDialog = ProgressDialog.show(MainActivity.this, "", "连接中", true, false);
            btnConnect.setEnabled(false);

            getUartService().connect(edtMac.getText().toString());
        }
    };

    View.OnClickListener btnGetListClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            progressDialog = ProgressDialog.show(MainActivity.this, "", "获取列表中", true, false);
            // 在每发一个命令前，都要重置fit实时传输解析器
            fit.rstDecoder();
            // 保存蓝牙数据接收的缓冲区
            byteArrayOutputStream = new ByteArrayOutputStream();
            // 当前命令类型
            commandType = CommandType.getHistoryList;
            // 获取命令
            commandBase = new GetHistoriesListCommand(Environment.getExternalStorageDirectory() + "/getlist.fit");
            // 将命令数据按8个一包发送
            commandBase.splitPackageSend(commandBase.getCommandData(), 8, new PackageSender() {
                @Override
                public void send(byte[] bytes) {
                    // 向UART写入数据，如果失败将当前包最大重试次数设置20，每包数据间隔为50ms
                    writeBytes(getUartService(), bytes, 20, 50);
                }
            });
        }
    };

    public static void writeBytes(UartService service, byte[] bytes, int timeTotry, long sleep) {
        if (service == null) return;
        int ttc = 0;
        boolean rs = service.writeRXCharacteristic(bytes);
        while (!rs && ttc < timeTotry) {
            try {
                Thread.sleep(sleep);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            rs = service.writeRXCharacteristic(bytes);
            ttc++;
        }
    }

    @Override
    protected void onBluetoothConnected() {
        Log.e(getClass().getName(), "onBluetoothConnected");
    }

    @Override
    protected void onBluetoothDisconnected() {
        Toast.makeText(getApplicationContext(), "连接断开！", Toast.LENGTH_LONG).show();
        progressDialog.dismiss();
        btnConnect.setEnabled(true);
    }

    @Override
    protected void onBluetoothDiscovered() {
        Toast.makeText(getApplicationContext(), "连接成功！", Toast.LENGTH_LONG).show();
        progressDialog.dismiss();
        getUartService().enableTXNotification();
        btnGetList.setEnabled(true);
    }

    @Override
    protected void onBluetoothReceiveData(byte[] data) {
        try {
            byteArrayOutputStream.write(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 使用fit实时数据解析器解析当前包
        int rs = fit.decOneBuf(data, data.length);
        // rs 为FIT_CONVERT_END_OF_FILE时表示遇到结束控制符，意味着数据已完整接收
        if (commandType == CommandType.getHistoryList && rs == FitConvertReturn.FIT_CONVERT_END_OF_FILE) {
            progressDialog.dismiss();
            Toast.makeText(getApplicationContext(), "获取列表完成，解析列表中...！", Toast.LENGTH_LONG).show();
            // 将接收到的数据转换为历史骑行列表
            HistoryResultParser historyResultParser = new HistoryResultParser();
            List<HistoryResultParser.HistoryActivity> activities = historyResultParser.parse(byteArrayOutputStream.toByteArray());
            Toast.makeText(getApplicationContext(), "解析列表完成，共有数据：" + activities.size() + "个", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onBluetoothNotSupportUART() {
        Log.e(getClass().getName(), "onBluetoothNotSupportUART");
    }

    @Override
    protected void onUartServiceConnected() {
        // 初始化UART服务
        getUartService().initialize();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);

        btnConnect = (Button) findViewById(R.id.btnConnect);
        btnGetList = (Button) findViewById(R.id.btnGetList);
        btnConnect.setOnClickListener(btnConnectOnClick);
        btnGetList.setOnClickListener(btnGetListClick);
        btnGetList.setEnabled(false);
        edtMac = (EditText) findViewById(R.id.edtMAC);
        edtMac.setText(sharedPreferences.getString("mac", ""));

        // 为实时fit数据包解析器初始化
        fit = new LibFit();
        fit.initDecoder();

    }


}
